
import './App.css'
import Header from './assets/components/header'
import ProductCard from './assets/components/productCard'

function App() {

  return (
    <>
      <div>
        <Header />
        <ProductCard 
          name="iPhone 16" 
          description="Latest Apple iPhone" 
          price="999.99" 
        />
        <ProductCard 
          name="Samsung Galaxy S24" 
          description="Latest Samsung Galaxy" 
          price="899.99" 
        />
      </div>
    </>
  )
}

export default App
