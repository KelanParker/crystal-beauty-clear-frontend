
export default function Header(){
    return (
        <header>
            <h1>Welcome to Crystal Beauty Clear</h1>
            <nav>
                <ul>
                    <li>Home</li>
                    <li>About</li>
                    <li>Services</li>
                    <li>Contact</li>
                </ul>
            </nav>
        </header>
    );
}