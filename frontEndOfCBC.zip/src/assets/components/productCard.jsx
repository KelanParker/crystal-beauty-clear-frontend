
export default function ProductCard(props){
    
    return (
        <div className="bg-red-500 p-4 rounded-lg shadow-md">
            <h1 className="text-xl font-bold">{props.name}</h1>
            <p className="text-gray-700">{props.description}</p>
            <p className="text-lg font-semibold">Price: ${props.price}</p>
            <button className="bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-600" >Add to Cart</button>
        </div>
    );
}